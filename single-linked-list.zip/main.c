#include<stdio.h>
#include<stdlib.h>
struct node *start=NULL;
struct node *ptr,*newnode,*preptr;
int key;
int num;
struct node
{
    int data;
    struct node *next;
};
void create();
void display();
void insert_beg();
void insert_end();
void insert_before();
void delete_beg();
void delete_end();
void delete_before();
void main()
{
    printf("**create\n**display\n**insert_beg\n**insert_end\n**insert_before\n**delete_beg\n**delete_end\n");
  do{
      int option;
  printf("enter your option:");
  scanf("%d",&option);
  
    switch(option)
    {
      case 1:create();
      break;
      case 2:display();
      break;
      case 3:insert_beg();
      break;
      case 4:insert_end();
      break;
      case 5:insert_before();
      break;
      case 6:delete_beg();
      break;
      case 7:delete_end();
      break;
       case 8:delete_before();
      break;
      case 9:exit(0);
      break;
      default:
      printf("linked list may not contain anything");
    }
  }while(1);
}
void create()
{
    int num;
    printf("enter your number:");
    scanf("%d",&num);
    while(num!=-1)
    {
        newnode=(struct node*)malloc(sizeof(struct node));
        newnode->data=num;
        if(start==NULL)
        {
            start=newnode;
            newnode->next=NULL;
        }
        else
        {
            ptr=start;
            while(ptr->next!=NULL)
            {
               ptr=ptr->next;
            }
             ptr->next=newnode;
                newnode->next=NULL;
        }
        printf("enter -1 to exit this loop or continue \n");
        scanf("%d",&num);
    }
}


void display()
{
    struct node *ptr;
    ptr=start;
    while(ptr->next!=NULL)
    {
        printf("%d\n",ptr->data);
        ptr=ptr->next;
    }
    printf("%d\n",ptr->data);
}

void insert_beg()
{
    printf("enter value");
    scanf("%d",&num);
    newnode=(struct node*)malloc(sizeof(struct node));
        newnode->data=num;
    ptr=start;
  start=newnode;
  newnode->next=ptr;
}


void insert_end()
{
    printf("enter value");
    scanf("%d",&num);
    newnode=(struct node*)malloc(sizeof(struct node));
        newnode->data=num;
    ptr=start;
    while(ptr->next!=NULL)
    {
        ptr=ptr->next;
    }
    ptr->next=newnode;
    newnode->next=NULL;
}


void insert_before()
{
    printf("enter value");
    scanf("%d",&num);
    newnode=(struct node*)malloc(sizeof(struct node));
        newnode->data=num;
    ptr=start;
    int key;
    printf("enter a value to insert before:");
    scanf("%d",&key);
    while(ptr->data!=key)
    {
        preptr=ptr;
        ptr=ptr->next;
    }
    preptr->next=newnode;
    newnode->next=ptr;
}


void delete_beg()
{
    if(start==NULL)
    {
        printf("linked list is empty\n");
    }
    else
    {
    ptr=start;
    start=start->next;
    free(ptr);
    }
}

void delete_end()
{
    if(start==NULL)
    {
        printf("linked list is empty\n");
    }
    else
    {
        ptr=start;
    while(ptr->next!=NULL)
    {
        preptr=ptr;
     ptr=ptr->next;   
    }
    preptr->next=NULL;
    free(ptr);
}
}

void delete_before()
{
    printf("enter a value to delete before:");
    scanf("%d",&key);
    while(ptr->data!=key)
    {
        preptr=ptr;
        ptr=ptr->next;
    }
    preptr->next=ptr->next;
    free(ptr);
}

